``tornado.httpserver`` --- Non-blocking HTTP server
===================================================

.. automodule:: tornado.httpserver

   HTTP Server
   -----------
   .. autoclass:: HTTPServer
      :members:
